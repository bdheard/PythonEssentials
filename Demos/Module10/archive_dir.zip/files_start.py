#
# Files
#

# open a file for writing tand create it if doesn't exist


# write to file


# close the file


# open the file for appending text to the end 


# write additonal data to file


# open a file for reading if it was opened successfuly the whole thing in one go


# read one line at a time

