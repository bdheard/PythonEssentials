#
# Working with the OS
#

import datetime
from datetime import date, time, timedelta
import time

def main():
    # Print the name of the OS

    # Check for if an item exists and what is its type

    # work with file paths


    # read modification date


    # Calculate how long ago the file was modified


if __name__ == "__main__":
    main()
